from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import joblib
import pandas as pd

app   = FastAPI(title="Loan Approval Predictor")
model = joblib.load("model/loan_model.pkl")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

class LoanApplication(BaseModel):
    age:          int
    income:       float
    credit_score: int

@app.get("/")
def root():
    return FileResponse("static/index.html")

@app.post("/predict")
def predict(data: LoanApplication):
    income_per_age      = data.income / data.age
    credit_income_ratio = data.credit_score / (data.income / 1000)
    age_group           = 0 if data.age < 30 else (1 if data.age < 50 else 2)
    income_band         = 0 if data.income < 40000 else (1 if data.income < 80000 else 2)
    credit_band         = 0 if data.credit_score < 580 else (
                          1 if data.credit_score < 670 else (
                          2 if data.credit_score < 740 else 3))

    features = pd.DataFrame([{
        'Age':                 data.age,
        'Income (PKR)':        data.income,
        'Credit Score':        data.credit_score,
        'income_per_age':      income_per_age,
        'credit_income_ratio': credit_income_ratio,
        'age_group':           age_group,
        'income_band':         income_band,
        'credit_band':         credit_band
    }])

    prediction  = model.predict(features)[0]
    probability = model.predict_proba(features)[0][1]

    credit_label = ["Poor", "Fair", "Good", "Excellent"][credit_band]
    income_label = ["Low", "Medium", "High"][income_band]

    if prediction == 1:
        if probability >= 0.80:
            reason = "Strong credit score, healthy income, and age profile all indicate low risk."
        else:
            reason = "Acceptable profile with moderate risk. Meets minimum criteria for approval."
    else:
        if data.credit_score < 580:
            reason = "Credit score is too low. Work on improving your credit history first."
        elif data.income < 30000:
            reason = "Income is insufficient to support loan repayment reliably."
        else:
            reason = "Overall risk profile does not meet current approval threshold."

    return {
        "status":       "Approved" if prediction == 1 else "Rejected",
        "confidence":   round(float(probability) * 100, 2),
        "credit_band":  credit_label,
        "income_band":  income_label,
        "reason":       reason
    }
