# 🏦 Loan Approval Predictor
ML-powered loan eligibility predictor built with FastAPI + Random Forest.

## 📁 Project Structure
```
loan_predictor/
├── model/
│   └── loan_model.pkl     ← trained ML model
├── static/
│   └── index.html         ← frontend UI
├── train.py               ← ML training script
├── main.py                ← FastAPI backend
├── loan_data.xlsx         ← dataset (200 rows)
└── requirements.txt
```

## ▶️ How to Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Train the model (only needed first time)
```bash
python train.py
```

### Step 3 — Start the server
```bash
uvicorn main:app --reload
```

### Step 4 — Open the app
Go to: http://127.0.0.1:8000

## 🔗 API Endpoints
| Method | URL        | Description          |
|--------|------------|----------------------|
| GET    | /          | Frontend UI          |
| POST   | /predict   | Get loan prediction  |
| GET    | /docs      | Auto API docs        |

## 📊 POST /predict — Request Body
```json
{
  "age": 32,
  "income": 75000,
  "credit_score": 720
}
```

## ✅ Response
```json
{
  "status": "Approved",
  "confidence": 84.5,
  "credit_band": "Good",
  "income_band": "Medium",
  "reason": "Strong credit score, healthy income, and age profile all indicate low risk."
}
```
