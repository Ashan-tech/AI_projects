import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, roc_auc_score, accuracy_score
import joblib

# ── STEP 1: LOAD DATA ────────────────────────────────────────────────
df = pd.read_excel("loan_data.xlsx")
print("="*50)
print("📂 DATA LOADED")
print("="*50)
print(df.head())
print(f"\nShape: {df.shape}")
print(f"\nStatus counts:\n{df['Status'].value_counts()}")

# ── STEP 2: PREPARE TARGET ───────────────────────────────────────────
df['approved'] = (df['Status'] == 'Approved').astype(int)

# ── STEP 3: FEATURE ENGINEERING ─────────────────────────────────────
age          = df['Age']
income       = df['Income (PKR)']
credit_score = df['Credit Score']

df['income_per_age']      = income / age
df['credit_income_ratio'] = credit_score / (income / 1000)
df['age_group']           = pd.cut(age, bins=[0,30,50,100], labels=[0,1,2]).astype(int)
df['income_band']         = pd.cut(income, bins=[0,40000,80000,999999], labels=[0,1,2]).astype(int)
df['credit_band']         = pd.cut(credit_score, bins=[0,580,670,740,900], labels=[0,1,2,3]).astype(int)

print("\n" + "="*50)
print("🔧 FEATURE ENGINEERING DONE")
print("="*50)
print(df[['income_per_age','credit_income_ratio','age_group','income_band','credit_band']].head())

# ── STEP 4: SPLIT DATA ───────────────────────────────────────────────
FEATURES = ['Age', 'Income (PKR)', 'Credit Score',
            'income_per_age', 'credit_income_ratio',
            'age_group', 'income_band', 'credit_band']

X = df[FEATURES]
y = df['approved']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print("\n" + "="*50)
print("✂️  DATA SPLIT")
print("="*50)
print(f"Training samples : {len(X_train)}")
print(f"Testing samples  : {len(X_test)}")

# ── STEP 5: TRAIN MODEL ──────────────────────────────────────────────
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('model',  RandomForestClassifier(n_estimators=100, random_state=42))
])

pipeline.fit(X_train, y_train)
print("\n✅ Model trained!")

# ── STEP 6: EVALUATION ───────────────────────────────────────────────
y_pred    = pipeline.predict(X_test)
y_proba   = pipeline.predict_proba(X_test)[:, 1]
acc       = accuracy_score(y_test, y_pred)
roc_auc   = roc_auc_score(y_test, y_proba)
cv_scores = cross_val_score(pipeline, X, y, cv=5, scoring='accuracy')

print("\n" + "="*50)
print("📋 EVALUATION RESULTS")
print("="*50)
print(f"✅ Accuracy     : {acc*100:.2f}%")
print(f"📊 ROC-AUC      : {roc_auc:.4f}")
print(f"🔁 CV Scores    : {cv_scores.round(4)}")
print(f"📈 CV Mean±Std  : {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
print("\n📋 Classification Report:")
print(classification_report(y_test, y_pred, target_names=['Rejected','Approved']))

# ── STEP 7: FEATURE IMPORTANCE ───────────────────────────────────────
rf         = pipeline.named_steps['model']
importance = pd.Series(rf.feature_importances_, index=FEATURES).sort_values(ascending=False)

print("="*50)
print("🌟 FEATURE IMPORTANCES")
print("="*50)
for feat, score in importance.items():
    bar = "█" * int(score * 40)
    print(f"  {feat:<22} {score:.4f}  {bar}")

# ── STEP 8: SAVE MODEL ───────────────────────────────────────────────
joblib.dump(pipeline, 'model/loan_model.pkl')
print("\n✅ Model saved → model/loan_model.pkl")
