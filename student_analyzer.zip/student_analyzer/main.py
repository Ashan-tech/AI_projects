import os
import io
import base64
import uuid
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from fpdf import FPDF

from fastapi import FastAPI, UploadFile, File, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# ── app setup ────────────────────────────────────────────────────────────────
app = FastAPI(title="Student Performance Analyzer")
app.mount("/static",  StaticFiles(directory="static"),  name="static")
app.mount("/reports", StaticFiles(directory="reports"), name="reports")
templates = Jinja2Templates(directory="templates")

UPLOAD_DIR = Path("uploads")
REPORT_DIR = Path("reports")

# ── helpers ───────────────────────────────────────────────────────────────────

def fig_to_b64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=130)
    buf.seek(0)
    plt.close(fig)
    return base64.b64encode(buf.read()).decode()


def load_and_validate(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()

    # auto-detect student name column
    name_col = None
    for c in df.columns:
        if c.lower() in ("name", "student", "student_name", "studentname"):
            name_col = c
            break
    if name_col is None:
        raise ValueError("CSV must have a column named 'Name' (or 'Student').")

    # rename to standard 'Name'
    df = df.rename(columns={name_col: "Name"})

    # numeric subject columns (everything except Name)
    subject_cols = [c for c in df.columns if c != "Name"]
    for col in subject_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if not subject_cols:
        raise ValueError("No numeric subject columns found.")

    df["Average"] = df[subject_cols].mean(axis=1).round(2)
    df["Total"]   = df[subject_cols].sum(axis=1).round(2)
    df["Grade"]   = df["Average"].apply(assign_grade)
    return df


def assign_grade(avg: float) -> str:
    if   avg >= 90: return "A+"
    elif avg >= 80: return "A"
    elif avg >= 70: return "B"
    elif avg >= 60: return "C"
    elif avg >= 50: return "D"
    else:           return "F"


def get_subject_cols(df: pd.DataFrame):
    return [c for c in df.columns if c not in ("Name", "Average", "Total", "Grade")]


# ── chart generators ──────────────────────────────────────────────────────────

def chart_top10(df: pd.DataFrame) -> str:
    top = df.nlargest(10, "Average").sort_values("Average")
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = sns.color_palette("viridis", len(top))
    bars = ax.barh(top["Name"], top["Average"], color=colors)
    ax.bar_label(bars, fmt="%.1f", padding=4, fontsize=9)
    ax.set_xlabel("Average Score")
    ax.set_title("Top 10 Students by Average")
    ax.set_xlim(0, 105)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig_to_b64(fig)


def chart_grade_dist(df: pd.DataFrame) -> str:
    grade_order = ["A+", "A", "B", "C", "D", "F"]
    counts = df["Grade"].value_counts().reindex(grade_order, fill_value=0)
    palette = ["#2ecc71","#27ae60","#3498db","#f39c12","#e67e22","#e74c3c"]
    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(counts.index, counts.values, color=palette, edgecolor="white", linewidth=1.2)
    ax.bar_label(bars, padding=3, fontsize=10)
    ax.set_xlabel("Grade")
    ax.set_ylabel("Number of Students")
    ax.set_title("Grade Distribution")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig_to_b64(fig)


def chart_subject_avg(df: pd.DataFrame) -> str:
    subj = get_subject_cols(df)
    avgs = df[subj].mean().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(x=avgs.index, y=avgs.values, palette="coolwarm", ax=ax)
    ax.set_ylabel("Class Average")
    ax.set_title("Average Score per Subject")
    ax.set_ylim(0, 105)
    for p in ax.patches:
        ax.annotate(f"{p.get_height():.1f}", (p.get_x()+p.get_width()/2, p.get_height()+1),
                    ha="center", va="bottom", fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig_to_b64(fig)


def chart_score_dist(df: pd.DataFrame) -> str:
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(df["Average"], bins=15, kde=True, color="#3498db",
                 edgecolor="white", linewidth=0.6, ax=ax)
    ax.axvline(df["Average"].mean(), color="red", linestyle="--", label=f'Mean: {df["Average"].mean():.1f}')
    ax.set_xlabel("Average Score")
    ax.set_ylabel("Count")
    ax.set_title("Score Distribution (with KDE)")
    ax.legend()
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig_to_b64(fig)


def chart_subject_box(df: pd.DataFrame) -> str:
    subj = get_subject_cols(df)
    melted = df[subj].melt(var_name="Subject", value_name="Score")
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.boxplot(data=melted, x="Subject", y="Score", palette="Set2", ax=ax)
    ax.set_title("Score Spread per Subject (Box Plot)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig_to_b64(fig)


# ── PDF export ────────────────────────────────────────────────────────────────

def export_pdf(df: pd.DataFrame, filename: str) -> Path:
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "Student Performance Report", ln=True, align="C")
    pdf.set_font("Helvetica", "", 11)
    pdf.cell(0, 8, f"Total Students: {len(df)}   |   Class Average: {df['Average'].mean():.2f}   |   Pass Rate: {(df['Average']>=50).mean()*100:.1f}%", ln=True, align="C")
    pdf.ln(4)

    # table header
    cols     = ["Name"] + get_subject_cols(df) + ["Average", "Grade"]
    col_w    = [45] + [20]*len(get_subject_cols(df)) + [25, 15]
    pdf.set_fill_color(52, 152, 219)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 9)
    for c, w in zip(cols, col_w):
        pdf.cell(w, 8, str(c), border=1, fill=True, align="C")
    pdf.ln()

    # rows
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Helvetica", "", 9)
    for i, (_, row) in enumerate(df[cols].iterrows()):
        fill = i % 2 == 0
        if fill:
            pdf.set_fill_color(235, 245, 255)
        for val, w in zip(row, col_w):
            pdf.cell(w, 7, str(val), border=1, fill=fill, align="C")
        pdf.ln()

    out = REPORT_DIR / filename
    pdf.output(str(out))
    return out


# ── routes ────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/upload")
async def upload_csv(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only CSV files are accepted.")

    uid      = uuid.uuid4().hex[:8]
    csv_path = UPLOAD_DIR / f"{uid}_{file.filename}"
    csv_path.write_bytes(await file.read())

    try:
        df = load_and_validate(csv_path)
    except Exception as e:
        csv_path.unlink(missing_ok=True)
        raise HTTPException(400, str(e))

    subj = get_subject_cols(df)

    # ── statistics ──────────────────────────────────────────────────
    stats = {
        "total":        int(len(df)),
        "class_avg":    round(float(df["Average"].mean()), 2),
        "highest":      round(float(df["Average"].max()),  2),
        "lowest":       round(float(df["Average"].min()),  2),
        "pass_rate":    round(float((df["Average"] >= 50).mean() * 100), 1),
        "topper":       df.loc[df["Average"].idxmax(), "Name"],
        "std_dev":      round(float(df["Average"].std()), 2),
        "subject_avgs": {s: round(float(df[s].mean()), 2) for s in subj},
    }

    # ── grade distribution (for JS chart) ───────────────────────────
    grade_order  = ["A+", "A", "B", "C", "D", "F"]
    grade_counts = df["Grade"].value_counts().reindex(grade_order, fill_value=0).to_dict()

    # ── top students ─────────────────────────────────────────────────
    top_students = df.nlargest(5, "Average")[["Name", "Average", "Grade"]].to_dict("records")

    # ── charts ───────────────────────────────────────────────────────
    charts = {
        "top10":       chart_top10(df),
        "grade_dist":  chart_grade_dist(df),
        "subject_avg": chart_subject_avg(df),
        "score_dist":  chart_score_dist(df),
        "subject_box": chart_subject_box(df),
    }

    # ── full table ────────────────────────────────────────────────────
    table_cols  = ["Name"] + subj + ["Average", "Total", "Grade"]
    table_data  = df[table_cols].fillna("N/A").to_dict("records")

    # ── PDF ───────────────────────────────────────────────────────────
    pdf_name = f"report_{uid}.pdf"
    export_pdf(df, pdf_name)

    return JSONResponse({
        "stats":        stats,
        "grade_counts": grade_counts,
        "top_students": top_students,
        "charts":       charts,
        "table":        table_data,
        "columns":      table_cols,
        "pdf_url":      f"/reports/{pdf_name}",
    })
