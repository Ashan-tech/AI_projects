/* ── file input & drag-drop ───────────────────────────── */
const input       = document.getElementById('csv-input');
const analyzeBtn  = document.getElementById('analyze-btn');
const fileDisplay = document.getElementById('file-name-display');
const dropZone    = document.getElementById('drop-zone');

let selectedFile = null;

function setFile(f) {
  if (!f || !f.name.endsWith('.csv')) {
    alert('Please select a .csv file.');
    return;
  }
  selectedFile = f;
  fileDisplay.textContent = f.name;
  analyzeBtn.disabled = false;
}

input.addEventListener('change', () => setFile(input.files[0]));
analyzeBtn.addEventListener('click', runAnalysis);

dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  setFile(e.dataTransfer.files[0]);
});

/* ── sample CSV ───────────────────────────────────────── */
function downloadSample() {
  const rows = [
    'Name,Math,Physics,Chemistry,English,Computer',
    'Ali Hassan,88,76,92,85,90',
    'Sara Ahmed,95,91,88,97,93',
    'Bilal Khan,72,65,70,68,75',
    'Ayesha Malik,60,55,63,70,58',
    'Usman Tariq,45,50,42,55,48',
    'Fatima Zahra,98,95,97,99,96',
    'Hamza Raza,83,79,85,80,88',
    'Zara Sheikh,70,72,68,75,65',
    'Imran Ali,55,60,50,58,52',
    'Nida Butt,78,74,80,76,82',
    'Saad Qureshi,90,88,92,85,94',
    'Maria Nadeem,65,68,62,70,60',
    'Asim Javed,40,45,38,50,42',
    'Hina Awan,87,83,89,91,86',
    'Yasir Shah,76,70,74,78,79',
  ];
  const blob = new Blob([rows.join('\n')], {type:'text/csv'});
  const a    = document.createElement('a');
  a.href     = URL.createObjectURL(blob);
  a.download = 'sample_students.csv';
  a.click();
}

/* ── main analysis ────────────────────────────────────── */
async function runAnalysis() {
  if (!selectedFile) return;

  document.getElementById('results').classList.add('hidden');
  document.getElementById('spinner').classList.remove('hidden');

  const fd = new FormData();
  fd.append('file', selectedFile);

  try {
    const res  = await fetch('/upload', { method:'POST', body:fd });
    const data = await res.json();

    if (!res.ok) { alert('Error: ' + (data.detail || 'Unknown error')); return; }

    renderStats(data.stats);
    renderTopStudents(data.top_students);
    renderCharts(data.charts);
    renderTable(data.columns, data.table);
    document.getElementById('pdf-link').href = data.pdf_url;

    document.getElementById('results').classList.remove('hidden');
    document.getElementById('results').scrollIntoView({behavior:'smooth'});
  } catch(err) {
    alert('Network error: ' + err.message);
  } finally {
    document.getElementById('spinner').classList.add('hidden');
  }
}

/* ── stat cards ───────────────────────────────────────── */
const STAT_DEFS = [
  { key:'total',    label:'Total Students', icon:'fa-users',         accent:'#3949ab', fmt: v => v },
  { key:'class_avg',label:'Class Average',  icon:'fa-chart-line',    accent:'#0891b2', fmt: v => v + '%' },
  { key:'topper',   label:'Top Student',    icon:'fa-trophy',        accent:'#d97706', fmt: v => v },
  { key:'pass_rate',label:'Pass Rate',      icon:'fa-circle-check',  accent:'#16a34a', fmt: v => v + '%' },
  { key:'highest',  label:'Highest Avg',    icon:'fa-arrow-trend-up',accent:'#9333ea', fmt: v => v },
  { key:'lowest',   label:'Lowest Avg',     icon:'fa-arrow-trend-down',accent:'#dc2626', fmt: v => v },
  { key:'std_dev',  label:'Std Deviation',  icon:'fa-sigma',         accent:'#0f766e', fmt: v => v },
];

function renderStats(stats) {
  const grid = document.getElementById('stats-grid');
  grid.innerHTML = '';
  STAT_DEFS.forEach(({key,label,icon,accent,fmt}) => {
    const val = stats[key];
    if (val === undefined) return;
    grid.insertAdjacentHTML('beforeend', `
      <div class="stat-card" style="--accent:${accent}">
        <div class="stat-icon"><i class="fa-solid ${icon}"></i></div>
        <div class="stat-val">${fmt(val)}</div>
        <div class="stat-lbl">${label}</div>
      </div>`);
  });
}

/* ── top 5 ────────────────────────────────────────────── */
function renderTopStudents(list) {
  const tb = document.getElementById('top-tbody');
  tb.innerHTML = list.map((s,i)=>`
    <tr>
      <td>${i+1}</td>
      <td><strong>${s.Name}</strong></td>
      <td>${s.Average}</td>
      <td><span class="badge grade-${s.Grade.replace('+','\\+')}" >${s.Grade}</span></td>
    </tr>`).join('');
}

/* ── charts ───────────────────────────────────────────── */
function renderCharts(charts) {
  document.getElementById('chart-top10'  ).src = 'data:image/png;base64,' + charts.top10;
  document.getElementById('chart-grade'  ).src = 'data:image/png;base64,' + charts.grade_dist;
  document.getElementById('chart-subject').src = 'data:image/png;base64,' + charts.subject_avg;
  document.getElementById('chart-hist'   ).src = 'data:image/png;base64,' + charts.score_dist;
  document.getElementById('chart-box'    ).src = 'data:image/png;base64,' + charts.subject_box;
}

/* ── data table ───────────────────────────────────────── */
function renderTable(cols, rows) {
  document.getElementById('data-thead').innerHTML =
    '<tr>' + cols.map(c=>`<th>${c}</th>`).join('') + '</tr>';

  const GRADE_COLS = new Set(['Grade']);
  document.getElementById('data-tbody').innerHTML = rows.map(row =>
    '<tr>' + cols.map(c => {
      const v = row[c] ?? '';
      if (GRADE_COLS.has(c)) {
        const cls = 'grade-' + String(v).replace('+', '\\+');
        return `<td><span class="badge ${cls}">${v}</span></td>`;
      }
      return `<td>${v}</td>`;
    }).join('') + '</tr>'
  ).join('');
}
