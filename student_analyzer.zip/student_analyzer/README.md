# Student Performance Analyzer

A mini web app built with **FastAPI + Jinja2** (frontend) and **Pandas, NumPy, Matplotlib, Seaborn** (data analysis).

---

## Project Structure

```
student_analyzer/
├── main.py               ← FastAPI app (backend + routes)
├── requirements.txt
├── templates/
│   └── index.html        ← Jinja2 HTML template
├── static/
│   ├── css/style.css
│   └── js/app.js
├── uploads/              ← temp CSV storage (auto-created)
└── reports/              ← PDF exports (auto-created)
```

---

## How to Run

### 1. Create & activate virtual environment
```bash
cd student_analyzer
python -m venv venv

# Windows
venv\Scripts\activate

# Linux / Mac
source venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Start the server
```bash
uvicorn main:app --reload
```

### 4. Open browser
```
http://127.0.0.1:8000
```

---

## CSV Format

Your CSV must have:
- A column named **`Name`** (or `Student` / `StudentName`)
- One or more **numeric subject columns** (e.g. Math, Physics, English...)

Example:
```
Name,Math,Physics,Chemistry,English,Computer
Ali Hassan,88,76,92,85,90
Sara Ahmed,95,91,88,97,93
...
```

Click **"Download sample CSV"** in the app to get a ready-made example.

---

## Features

| Feature | How |
|---|---|
| Load CSV | Drag & drop or file picker |
| Calculate averages | Pandas `.mean()` per row & per subject |
| Numpy stats | `np.std`, min, max via pandas+numpy |
| Find toppers | `df.nlargest()` |
| Charts (5 types) | Matplotlib + Seaborn, returned as base64 PNG |
| Export PDF | fpdf2 library, auto-generated table |

---

## Tech Stack

- **FastAPI** — backend API + routing
- **Jinja2** — HTML templating
- **Pandas** — CSV loading, averages, grades
- **NumPy** — under-the-hood numerical ops
- **Matplotlib + Seaborn** — all 5 charts
- **fpdf2** — PDF report generation
